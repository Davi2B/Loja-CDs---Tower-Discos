/* L�gico_cd: */

CREATE TABLE usuario (
    login VARCHAR,
    nome_usuario VARCHAR,
    email VARCHAR,
    senha NUMBER,
    id_usuario NUMBER PRIMARY KEY
);

CREATE TABLE produto (
    preco NUMERIC,
    autor VARCHAR,
    id_produto NUMBER PRIMARY KEY,
    fk_cliente_id_cliente NUMBER,
    fk_usuario_id_usuario NUMBER
);

CREATE TABLE cliente (
    nome_cliente VARCHAR,
    senha NUMBER,
    email VARCHAR,
    id_cliente NUMBER PRIMARY KEY
);
 
ALTER TABLE produto ADD CONSTRAINT FK_produto_2
    FOREIGN KEY (fk_cliente_id_cliente)
    REFERENCES cliente (id_cliente)
    ON DELETE RESTRICT;
 
ALTER TABLE produto ADD CONSTRAINT FK_produto_3
    FOREIGN KEY (fk_usuario_id_usuario)
    REFERENCES usuario (id_usuario)
    ON DELETE RESTRICT;